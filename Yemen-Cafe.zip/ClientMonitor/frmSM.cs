﻿namespace ScreenMonitor
{
    using System;
    using System.Threading.Tasks;
    using System.Windows.Forms;


    public partial class frmSM : Form
    {
        private int port;
        private string ip;
        public frmSM(int port,string ip)
        {
            InitializeComponent();
            this.port = port;
            this.ip = ip;

            this.Text = ip + ":" + port.ToString();
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if(keyData == Keys.Escape)
            {
                this.Close();
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }

       
        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                 Task.Factory.StartNew(()=>CaptureScreen());
            }
            catch { }
        }

        private Task<bool> CaptureScreen()
        {
            Task<bool> res = null;
            try
            {
               res = new Task<bool>(() =>
               {
                   pictureBox1.Image = (new MyImage(this.Width, this.Height, this.port, this.ip).GetImage);
                   return true;
               });

                res.Start();
            }
            catch { }

            return res;
        }
    }
}
