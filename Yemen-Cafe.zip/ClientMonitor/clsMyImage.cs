﻿namespace ScreenMonitor
{
    using System.Drawing;
    using System.Text;
    public class MyImage
    {
        private int width;
        private int height;
        private Image image;
        private int port;
        private string ip;
        public MyImage(
            int width,
            int height,
            int port,
            string ip
            )
        {
            this.width = width;
            this.height = height;
            this.port = port;
            this.ip = ip;
            SocketCommander sc = new SocketCommander((ushort)port,ip);
            byte[] buffer = null;

            if(sc.GetObject(new Packet(Command.SCSH,Encoding.UTF8.GetBytes(width.ToString() + ";" + height.ToString())),ref buffer))
            {
                this.image = BytesToImage(buffer);
            }   
        }

        public static Image BytesToImage(byte[] ar)
        {
            Image i = null;

            try
            {
                using (System.IO.MemoryStream ms = new System.IO.MemoryStream(ar))
                {
                    i = Image.FromStream(ms);
                }
            }
            catch { }

            return i;
        }

        public Image GetImage
        {
            get
            {
                 return this.image;
            }
        }
    }
}
