﻿namespace ScreenMonitor
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using System.Net.Sockets;
    public enum Command : byte
    {
        PING = 1,
        SCSH
    }

    public class Packet
    {
        private Command cmd;
        private byte[] data;

        internal Packet(Command cmd)
        {
            this.cmd = cmd;
            this.data = new byte[0];
        }

        public Packet(Command cmd, byte[] ar)
        {
            this.cmd = cmd;
            this.data = new byte[ar.Length];
            Array.Copy(ar, 0, this.data, 0, ar.Length);

        }

        public Packet(byte[] ar)
        {
            this.cmd = (Command)ar[0];
            this.data = new byte[ar.Length - 1];
            Array.Copy(ar, 1, this.data, 0, ar.Length - 1);
        }

        public byte[] ToBytes()
        {
            byte[] res = new byte[this.data.Length + 1];
            res[0] = (byte)this.cmd;

            Array.Copy(this.data, 0, res, 1, this.data.Length);
            return res;
        }

        public Command CommandInfo()
        {
            return this.cmd;
        }

        public string DataToString()
        {
            return Encoding.UTF8.GetString(this.data);
        }
    }

    public class SocketCommander
    {
        private ushort port;
        private string ip;

        public SocketCommander(ushort port, string ip)
        {
            this.port = port;
            this.ip = ip;
        }

        public bool GetObject(Packet p, ref byte[] res)
        {
            List<byte> r = new List<byte>();
            bool res0 = false;

            try
            {
                Socket s = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

                try
                {
                    s.Connect(this.ip, this.port);

                   
                    if (s.Send(p.ToBytes()) > 0)
                    {
                        byte[] buffer = new byte[1024 * 4];
                        byte[] buffer2;

                        int len = 0;

                        while ((len = s.Receive(buffer)) > 0)
                        {
                            buffer2 = new byte[len];
                            Array.Copy(buffer, 0, buffer2, 0, len);
                            r.AddRange(buffer2);

                        }

                    }

                    s.Close();

                    if(r.Count > 0)
                    {
                        res0 = true;
                    }
                }
                catch
                {
                }
            }
            catch
            {
            }

            res = r.ToArray();
            return res0;
        }

    }
}
